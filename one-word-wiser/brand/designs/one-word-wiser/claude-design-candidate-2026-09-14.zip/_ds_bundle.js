/* @ds-bundle: {"format":4,"namespace":"OneWordWiser_473976","components":[{"name":"Divider","sourcePath":"components/brand/Divider.jsx"},{"name":"StatusStamp","sourcePath":"components/brand/StatusStamp.jsx"},{"name":"Wordmark","sourcePath":"components/brand/Wordmark.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"EmailSignup","sourcePath":"components/core/EmailSignup.jsx"},{"name":"ClosingThought","sourcePath":"components/study/ClosingThought.jsx"},{"name":"FurtherReading","sourcePath":"components/study/FurtherReading.jsx"},{"name":"HebrewWord","sourcePath":"components/study/HebrewWord.jsx"},{"name":"QuestionList","sourcePath":"components/study/QuestionList.jsx"},{"name":"ReadingNote","sourcePath":"components/study/ReadingNote.jsx"},{"name":"SectionLabel","sourcePath":"components/study/SectionLabel.jsx"},{"name":"SeriesMasthead","sourcePath":"components/study/SeriesMasthead.jsx"},{"name":"SourceList","sourcePath":"components/study/SourceList.jsx"},{"name":"VerseBlock","sourcePath":"components/study/VerseBlock.jsx"}],"sourceHashes":{"components/brand/Divider.jsx":"a8cadb11f3d8","components/brand/StatusStamp.jsx":"204d12699f30","components/brand/Wordmark.jsx":"c86312a70cdc","components/core/Button.jsx":"3dd0da96d080","components/core/EmailSignup.jsx":"3869d216aa93","components/study/ClosingThought.jsx":"4d37bc217fb7","components/study/FurtherReading.jsx":"1f39b140ec72","components/study/HebrewWord.jsx":"3fa5454d3b9b","components/study/QuestionList.jsx":"8b43e0a7cfb6","components/study/ReadingNote.jsx":"0460d07206cc","components/study/SectionLabel.jsx":"07a71381be19","components/study/SeriesMasthead.jsx":"31489a9dedf7","components/study/SourceList.jsx":"d623a59dabc0","components/study/VerseBlock.jsx":"d91e605c0f98","ui_kits/daily-letter/LetterBody.jsx":"f166152f15f3","ui_kits/daily-letter/LetterFooter.jsx":"3fcdff555d41","ui_kits/daily-letter/LetterHeader.jsx":"17aaf5ca95d7","ui_kits/daily-letter/WelcomePage.jsx":"8015d90dd69b","ui_kits/rabbis-notes/NotesToolbar.jsx":"962c21f41b72","ui_kits/rabbis-notes/SourcesPanel.jsx":"318984edd5af","ui_kits/rabbis-notes/StudyPage.jsx":"2d4befd17f2f","ui_kits/rabbis-notes/notes-data.js":"5f7e6cd5c35b"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.OneWordWiser_473976 = window.OneWordWiser_473976 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Divider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* The only ornament this system allows. Native text, never an image. */
const GLYPHS = {
  diamond: "\u25C6",
  asterism: "\u2042",
  dots: "\u00B7 \u00B7 \u00B7"
};
function Divider({
  variant = "diamond",
  tone = "accent",
  width = "100%",
  style,
  ...rest
}) {
  const color = tone === "accent" ? "var(--rule-accent)" : "var(--text-faint)";
  if (variant === "rule") {
    return /*#__PURE__*/React.createElement("hr", _extends({
      style: {
        border: 0,
        borderTop: "var(--border-hairline) solid var(--rule-hairline)",
        width,
        margin: "var(--gap-block) 0",
        ...style
      }
    }, rest));
  }
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "separator",
    "aria-hidden": "true",
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-4)",
      width,
      margin: "var(--gap-block) 0",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 1,
      background: "var(--rule-hairline)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color,
      fontSize: variant === "diamond" ? 7 : 15,
      lineHeight: 1,
      letterSpacing: "0.2em",
      fontFamily: "var(--font-serif)"
    }
  }, GLYPHS[variant]), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 1,
      background: "var(--rule-hairline)"
    }
  }));
}
Object.assign(__ds_scope, { Divider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Divider.jsx", error: String((e && e.message) || e) }); }

// components/brand/StatusStamp.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function StatusStamp({
  children,
  tone = "quiet",
  style,
  ...rest
}) {
  const inverse = tone === "inverse";
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      font: "var(--text-role-caption)",
      fontSize: "var(--type-micro)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-status)",
      color: inverse ? "var(--text-on-navy)" : "var(--status-ink)",
      background: inverse ? "var(--surface-inverse)" : "var(--status-surface)",
      padding: "var(--space-2) var(--space-4)",
      borderRadius: "var(--radius-sm)",
      display: "inline-block",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { StatusStamp });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/StatusStamp.jsx", error: String((e && e.message) || e) }); }

// components/brand/Wordmark.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Provisional marks. The final logos were not supplied; these stand-ins are
   labeled provisional wherever they appear in review material. */
const SQUARE = "/assets/logo-square-provisional.png";
const WORDMARK = "/assets/wordmark-provisional.png";
function Wordmark({
  variant = "wordmark",
  height,
  assetBase = "",
  showProvisionalNote = false,
  style,
  ...rest
}) {
  const isSquare = variant === "square";
  const src = assetBase + (isSquare ? SQUARE : WORDMARK);
  const h = height || (isSquare ? 48 : 96);
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      flexDirection: "column",
      alignItems: "center",
      gap: "var(--space-2)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: "One Word Wiser",
    style: {
      height: h,
      width: "auto",
      display: "block",
      borderRadius: isSquare ? "var(--radius-sm)" : 0
    }
  }), showProvisionalNote && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--text-role-caption)",
      color: "var(--text-faint)",
      letterSpacing: "var(--tracking-status)",
      textTransform: "uppercase",
      fontSize: "var(--type-micro)"
    }
  }, "Provisional mark"));
}
Object.assign(__ds_scope, { Wordmark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Wordmark.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Button({
  children,
  variant = "primary",
  size = "md",
  href,
  disabled,
  style,
  ...rest
}) {
  const pad = size === "sm" ? "var(--space-2) var(--space-4)" : "var(--space-3) var(--space-5)";
  const tones = {
    primary: {
      background: "var(--surface-inverse)",
      color: "var(--text-on-navy)",
      border: "var(--border-hairline) solid var(--navy-800)"
    },
    secondary: {
      background: "transparent",
      color: "var(--navy-800)",
      border: "var(--border-hairline) solid var(--navy-800)"
    },
    quiet: {
      background: "transparent",
      color: "var(--text-muted)",
      border: "var(--border-hairline) solid transparent"
    }
  };
  const base = {
    font: "var(--text-role-body)",
    fontSize: size === "sm" ? "var(--type-body-sm)" : "var(--type-body)",
    lineHeight: 1.1,
    padding: pad,
    borderRadius: "var(--radius-sm)",
    cursor: disabled ? "default" : "pointer",
    textDecoration: "none",
    display: "inline-block",
    opacity: disabled ? "var(--opacity-disabled)" : 1,
    transition: "opacity var(--duration-base) var(--ease-standard)",
    ...tones[variant],
    ...style
  };
  const onEnter = e => {
    if (!disabled) e.currentTarget.style.opacity = "var(--opacity-hover)";
  };
  const onLeave = e => {
    if (!disabled) e.currentTarget.style.opacity = "1";
  };
  if (href) return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    style: base,
    onMouseEnter: onEnter,
    onMouseLeave: onLeave
  }, rest), children);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    style: base,
    onMouseEnter: onEnter,
    onMouseLeave: onLeave
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/EmailSignup.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function EmailSignup({
  label = "The Bible wasn't written in English.",
  note,
  buttonLabel = "Subscribe",
  onSubmit,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("form", _extends({
    onSubmit: e => {
      e.preventDefault();
      onSubmit && onSubmit(e);
    },
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-3)",
      maxWidth: "var(--measure-narrow)",
      ...style
    }
  }, rest), label && /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-role-body)",
      color: "var(--text-body)"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-2)"
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "email",
    required: true,
    placeholder: "you@example.com",
    "aria-label": "Email address",
    style: {
      flex: 1,
      font: "var(--text-role-body)",
      color: "var(--text-body)",
      background: "var(--surface-card)",
      border: "var(--border-hairline) solid var(--rule-hairline)",
      borderRadius: "var(--radius-sm)",
      padding: "var(--space-3) var(--space-4)",
      minWidth: 0
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary"
  }, buttonLabel)), note && /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-role-caption)",
      color: "var(--text-muted)"
    }
  }, note));
}
Object.assign(__ds_scope, { EmailSignup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/EmailSignup.jsx", error: String((e && e.message) || e) }); }

// components/study/ClosingThought.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ClosingThought({
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("p", _extends({
    style: {
      font: "var(--text-role-subtitle)",
      fontSize: "var(--type-body)",
      color: "var(--text-display)",
      textAlign: "center",
      maxWidth: "var(--measure-narrow)",
      margin: "0 auto",
      textWrap: "pretty",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { ClosingThought });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/study/ClosingThought.jsx", error: String((e && e.message) || e) }); }

// components/study/FurtherReading.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function FurtherReading({
  author,
  title,
  url,
  note,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-role-body)",
      fontSize: "var(--type-body-sm)",
      color: "var(--text-body)"
    }
  }, author, ": ", /*#__PURE__*/React.createElement("a", {
    href: url
  }, /*#__PURE__*/React.createElement("cite", {
    style: {
      fontStyle: "italic"
    }
  }, title))), note && /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-role-caption)",
      color: "var(--text-muted)",
      marginTop: "var(--space-1)",
      textWrap: "pretty"
    }
  }, note));
}
Object.assign(__ds_scope, { FurtherReading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/study/FurtherReading.jsx", error: String((e && e.message) || e) }); }

// components/study/HebrewWord.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Nikkud must survive as selectable text. Never ship the Hebrew as an image,
   and never strip the vowel marks to "clean up" the string. */
function HebrewWord({
  hebrew,
  pronunciation,
  size = "hero",
  align = "center",
  style,
  ...rest
}) {
  const hero = size === "hero";
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      textAlign: align,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    lang: "he",
    dir: "rtl",
    style: {
      fontFamily: "var(--font-hebrew)",
      fontSize: hero ? "var(--type-hebrew-hero)" : "var(--type-hebrew-inline)",
      fontWeight: "var(--weight-medium)",
      lineHeight: "var(--leading-hebrew)",
      color: "var(--text-hebrew)"
    }
  }, hebrew), pronunciation && /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-role-body)",
      fontSize: "var(--type-body-sm)",
      fontStyle: "italic",
      color: "var(--text-muted)",
      marginTop: hero ? "var(--space-2)" : "var(--space-1)"
    }
  }, pronunciation));
}
Object.assign(__ds_scope, { HebrewWord });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/study/HebrewWord.jsx", error: String((e && e.message) || e) }); }

// components/study/QuestionList.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function QuestionList({
  questions = [],
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("ol", _extends({
    style: {
      margin: 0,
      padding: 0,
      listStyle: "none",
      display: "grid",
      gap: "var(--space-3)",
      ...style
    }
  }, rest), questions.map((q, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      display: "grid",
      gridTemplateColumns: "auto 1fr",
      gap: "var(--space-3)",
      font: "var(--text-role-body)",
      fontSize: "var(--type-body-sm)",
      color: "var(--text-body)",
      textWrap: "pretty"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-faint)",
      fontVariantNumeric: "lining-nums"
    }
  }, i + 1, "."), /*#__PURE__*/React.createElement("span", null, q))));
}
Object.assign(__ds_scope, { QuestionList });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/study/QuestionList.jsx", error: String((e && e.message) || e) }); }

// components/study/ReadingNote.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ReadingNote({
  heading,
  children,
  reference,
  referenceUrl,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("section", _extends({
    style: {
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("h3", {
    style: {
      font: "var(--text-role-body)",
      fontWeight: "var(--weight-semibold)",
      color: "var(--text-display)",
      margin: "0 0 var(--space-2)"
    }
  }, heading), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--text-role-body)",
      fontSize: "var(--type-body-sm)",
      color: "var(--text-body)",
      margin: 0,
      textWrap: "pretty"
    }
  }, children), reference && /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-role-caption)",
      color: "var(--text-muted)",
      marginTop: "var(--space-2)"
    }
  }, referenceUrl ? /*#__PURE__*/React.createElement("a", {
    href: referenceUrl
  }, reference) : reference));
}
Object.assign(__ds_scope, { ReadingNote });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/study/ReadingNote.jsx", error: String((e && e.message) || e) }); }

// components/study/SectionLabel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SectionLabel({
  children,
  as: Tag = "h2",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      font: "var(--text-role-caption)",
      fontSize: "var(--type-section)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-section)",
      fontWeight: "var(--weight-semibold)",
      color: "var(--text-muted)",
      margin: "0 0 var(--space-3)",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { SectionLabel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/study/SectionLabel.jsx", error: String((e && e.message) || e) }); }

// components/study/SeriesMasthead.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SeriesMasthead({
  series = "The Rabbi’s Notes",
  publication = "One Word Wiser",
  assetBase = "",
  showMark = true,
  style,
  ...rest
}) {
  const kicker = {
    font: "var(--text-role-caption)",
    fontSize: "var(--type-micro)",
    textTransform: "uppercase",
    letterSpacing: "var(--tracking-status)",
    color: "var(--text-muted)"
  };
  return /*#__PURE__*/React.createElement("header", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "var(--space-4)",
      paddingBottom: "var(--space-3)",
      borderBottom: "var(--border-rule) solid var(--rule-strong)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-3)"
    }
  }, showMark && /*#__PURE__*/React.createElement(__ds_scope.Wordmark, {
    variant: "square",
    height: 26,
    assetBase: assetBase
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      ...kicker,
      color: "var(--text-body)",
      fontWeight: "var(--weight-semibold)"
    }
  }, series)), /*#__PURE__*/React.createElement("span", {
    style: kicker
  }, publication));
}
Object.assign(__ds_scope, { SeriesMasthead });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/study/SeriesMasthead.jsx", error: String((e && e.message) || e) }); }

// components/study/SourceList.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SourceList({
  sources = [],
  label = "Sources",
  footnote,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      font: "var(--text-role-caption)",
      color: "var(--text-muted)",
      textWrap: "pretty",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", null, label, ": "), sources.map((s, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-faint)"
    }
  }, " \xB7 "), /*#__PURE__*/React.createElement("a", {
    href: s.url
  }, s.label))), footnote && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-1)",
      color: "var(--text-faint)"
    }
  }, footnote));
}
Object.assign(__ds_scope, { SourceList });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/study/SourceList.jsx", error: String((e && e.message) || e) }); }

// components/study/VerseBlock.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function VerseBlock({
  verse,
  reference,
  context,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("figure", _extends({
    style: {
      margin: 0,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("blockquote", {
    style: {
      margin: 0,
      background: "var(--surface-quote)",
      padding: "var(--space-5) var(--space-5)",
      borderLeft: "var(--border-rule) solid var(--rule-accent)",
      borderRadius: "var(--radius-sm)",
      font: "var(--text-role-subtitle)",
      color: "var(--text-display)",
      textWrap: "pretty"
    }
  }, verse), reference && /*#__PURE__*/React.createElement("figcaption", {
    style: {
      font: "var(--text-role-caption)",
      color: "var(--text-muted)",
      marginTop: "var(--space-2)"
    }
  }, reference), context && /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--text-role-body)",
      color: "var(--text-body)",
      margin: "var(--gap-paragraph) 0 0",
      textWrap: "pretty"
    }
  }, context));
}
Object.assign(__ds_scope, { VerseBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/study/VerseBlock.jsx", error: String((e && e.message) || e) }); }

// ui_kits/daily-letter/LetterBody.jsx
try { (() => {
/* Layout specimen. The body sentences are taken verbatim from the supplied sample
   return so that no teaching is invented here. */
const {
  HebrewWord,
  Divider,
  SectionLabel,
  SourceList,
  ClosingThought
} = window.OneWordWiser_473976;
function LetterBody({
  data
}) {
  const p = {
    font: "var(--text-role-body)",
    color: "var(--text-body)",
    margin: 0,
    textWrap: "pretty"
  };
  return /*#__PURE__*/React.createElement("article", {
    style: {
      display: "grid",
      gap: "var(--space-5)",
      maxWidth: "var(--measure-prose)",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--space-3)",
      justifyItems: "center",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: "var(--text-role-display)",
      color: "var(--text-display)",
      margin: 0,
      textWrap: "pretty"
    }
  }, data.title), /*#__PURE__*/React.createElement(HebrewWord, {
    hebrew: data.hebrew,
    pronunciation: data.pronunciation,
    size: "hero"
  })), /*#__PURE__*/React.createElement("blockquote", {
    style: {
      margin: 0,
      font: "var(--text-role-subtitle)",
      color: "var(--text-display)",
      textAlign: "center"
    }
  }, data.verse, /*#__PURE__*/React.createElement("footer", {
    style: {
      font: "var(--text-role-caption)",
      color: "var(--text-muted)",
      fontStyle: "normal",
      marginTop: "var(--space-2)"
    }
  }, data.verse_reference)), /*#__PURE__*/React.createElement(Divider, {
    variant: "diamond",
    style: {
      margin: 0
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: p
  }, data.context), /*#__PURE__*/React.createElement("p", {
    style: p
  }, data.word_note), /*#__PURE__*/React.createElement(ClosingThought, null, data.closing), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "var(--border-hairline) solid var(--rule-hairline)",
      paddingTop: "var(--space-4)",
      display: "grid",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    as: "h2"
  }, "Other mentions"), /*#__PURE__*/React.createElement(SourceList, {
    label: "Sources",
    sources: data.sources,
    footnote: data.footnote
  })));
}
Object.assign(window, {
  LetterBody
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/daily-letter/LetterBody.jsx", error: String((e && e.message) || e) }); }

// ui_kits/daily-letter/LetterFooter.jsx
try { (() => {
const {
  EmailSignup,
  Wordmark,
  Divider
} = window.OneWordWiser_473976;
function LetterFooter({
  assetBase = "../.."
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      display: "grid",
      gap: "var(--space-4)",
      justifyItems: "center",
      textAlign: "center",
      paddingTop: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement(Divider, {
    variant: "rule",
    style: {
      margin: 0,
      width: "100%"
    }
  }), /*#__PURE__*/React.createElement(Wordmark, {
    variant: "square",
    height: 40,
    assetBase: assetBase
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--text-role-body)",
      fontSize: "var(--type-body-sm)",
      color: "var(--text-muted)",
      maxWidth: "var(--measure-narrow)",
      margin: 0,
      textWrap: "pretty"
    }
  }, "The Bible wasn\u2019t written in English. One Hebrew word a day, and the verses it opens \u2014 Genesis to the Gospels. From Rabbi Evan Moffic. No Hebrew required."), /*#__PURE__*/React.createElement(EmailSignup, {
    label: null,
    note: "No Hebrew required.",
    style: {
      margin: "0 auto"
    }
  }));
}
Object.assign(window, {
  LetterFooter
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/daily-letter/LetterFooter.jsx", error: String((e && e.message) || e) }); }

// ui_kits/daily-letter/LetterHeader.jsx
try { (() => {
const {
  Wordmark,
  StatusStamp
} = window.OneWordWiser_473976;
function LetterHeader({
  assetBase = "../..",
  dateline
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: "grid",
      justifyItems: "center",
      gap: "var(--space-3)",
      paddingBottom: "var(--space-5)",
      borderBottom: "var(--border-hairline) solid var(--rule-hairline)"
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    variant: "wordmark",
    height: 96,
    assetBase: assetBase
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-role-caption)",
      fontSize: "var(--type-micro)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-status)",
      color: "var(--text-muted)"
    }
  }, dateline), /*#__PURE__*/React.createElement(StatusStamp, null, "Layout specimen \xB7 provisional wordmark"));
}
Object.assign(window, {
  LetterHeader
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/daily-letter/LetterHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/daily-letter/WelcomePage.jsx
try { (() => {
/* The publication's own page: approved description, tagline, and short social bio, verbatim. */
const {
  Wordmark,
  EmailSignup,
  Divider,
  SectionLabel,
  Button,
  StatusStamp
} = window.OneWordWiser_473976;
function WelcomePage({
  assetBase = "../.."
}) {
  const p = {
    font: "var(--text-role-body)",
    color: "var(--text-body)",
    margin: 0,
    textWrap: "pretty"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--space-6)",
      maxWidth: "var(--measure-prose)",
      margin: "0 auto",
      justifyItems: "center",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    variant: "wordmark",
    height: 110,
    assetBase: assetBase,
    showProvisionalNote: true
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      ...p,
      font: "var(--text-role-subtitle)"
    }
  }, "One Hebrew word, one rabbinic teaching, and one wiser way to live."), /*#__PURE__*/React.createElement(Divider, {
    variant: "diamond",
    style: {
      margin: 0
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: p
  }, "The Bible wasn\u2019t written in English. One Hebrew word a day, and the verses it opens \u2014 Genesis to the Gospels. From Rabbi Evan Moffic. No Hebrew required."), /*#__PURE__*/React.createElement(EmailSignup, {
    label: null,
    note: "Hebrew for Christians (and curious Jews), from a rabbi.",
    style: {
      margin: "0 auto"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--space-3)",
      justifyItems: "center",
      borderTop: "var(--border-hairline) solid var(--rule-hairline)",
      paddingTop: "var(--space-5)",
      width: "100%"
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    as: "h2"
  }, "The Rabbi\u2019s Notes"), /*#__PURE__*/React.createElement("p", {
    style: {
      ...p,
      fontSize: "var(--type-body-sm)",
      color: "var(--text-muted)"
    }
  }, "A one-page study companion: one passage, the Hebrew under it, two rabbinic readings, and two questions to discuss."), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    href: "../rabbis-notes/index.html"
  }, "See the sample page"), /*#__PURE__*/React.createElement(StatusStamp, null, "In prototype \xB7 not a live benefit")));
}
Object.assign(window, {
  WelcomePage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/daily-letter/WelcomePage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/rabbis-notes/NotesToolbar.jsx
try { (() => {
/* Review chrome around the page. Not part of the printed artifact. */
const {
  Button,
  StatusStamp
} = window.OneWordWiser_473976;
function NotesToolbar({
  view,
  onView,
  onPrint
}) {
  const tab = active => ({
    font: "var(--text-role-caption)",
    textTransform: "uppercase",
    letterSpacing: "var(--tracking-status)",
    padding: "var(--space-2) var(--space-3)",
    cursor: "pointer",
    background: "none",
    border: 0,
    borderBottom: "2px solid " + (active ? "var(--rule-strong)" : "transparent"),
    color: active ? "var(--text-body)" : "var(--text-faint)"
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 816,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "var(--space-4)",
      margin: "0 auto var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-2)"
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: tab(view === "page"),
    onClick: () => onView("page")
  }, "Page"), /*#__PURE__*/React.createElement("button", {
    style: tab(view === "sources"),
    onClick: () => onView("sources")
  }, "Sources")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement(StatusStamp, null, "Private review copy"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    onClick: onPrint
  }, "Print / save as PDF")));
}
Object.assign(window, {
  NotesToolbar
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/rabbis-notes/NotesToolbar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/rabbis-notes/SourcesPanel.jsx
try { (() => {
/* The separate source-reference view. Links are shown in full so they can be checked. */
const {
  SectionLabel,
  FurtherReading,
  StatusStamp
} = window.OneWordWiser_473976;
function SourcesPanel({
  data
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      width: 816,
      boxSizing: "border-box",
      background: "var(--surface-card)",
      padding: "44px 64px",
      fontFamily: "var(--font-serif)",
      display: "grid",
      gap: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionLabel, null, "Source references"), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      padding: 0,
      listStyle: "none",
      display: "grid",
      gap: "var(--space-3)"
    }
  }, data.sources.map((s, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      borderBottom: "var(--border-hairline) solid var(--rule-hairline)",
      paddingBottom: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-role-body)",
      fontSize: "var(--type-body-sm)"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: s.url
  }, s.label)), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-role-caption)",
      fontSize: "var(--type-micro)",
      color: "var(--text-faint)",
      wordBreak: "break-all",
      marginTop: 4
    }
  }, s.url))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionLabel, null, "Further reading"), /*#__PURE__*/React.createElement(FurtherReading, data.further_reading), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-role-caption)",
      fontSize: "var(--type-micro)",
      color: "var(--text-faint)",
      marginTop: "var(--space-2)"
    }
  }, "Link verified 2026-09-14.")), /*#__PURE__*/React.createElement(StatusStamp, null, data.footnote));
}
Object.assign(window, {
  SourcesPanel
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/rabbis-notes/SourcesPanel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/rabbis-notes/StudyPage.jsx
try { (() => {
/* The Rabbi's Notes — one-page study companion. Recreation of the supplied prototype. */
const {
  SeriesMasthead,
  SectionLabel,
  HebrewWord,
  VerseBlock,
  ReadingNote,
  QuestionList,
  ClosingThought,
  FurtherReading,
  SourceList,
  StatusStamp,
  Divider
} = window.OneWordWiser_473976;
function StudyPage({
  data,
  assetBase = "../..",
  showRule = true
}) {
  return /*#__PURE__*/React.createElement("article", {
    style: {
      width: 816,
      minHeight: 1056,
      boxSizing: "border-box",
      background: "var(--surface-card)",
      padding: "44px 64px 34px",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-5)",
      fontFamily: "var(--font-serif)",
      color: "var(--text-body)"
    }
  }, /*#__PURE__*/React.createElement(SeriesMasthead, {
    series: "The Rabbi\u2019s Notes",
    publication: "One Word Wiser",
    assetBase: assetBase
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      display: "grid",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: "var(--text-role-title)",
      color: "var(--text-display)",
      margin: 0,
      textWrap: "pretty"
    }
  }, data.title), /*#__PURE__*/React.createElement(HebrewWord, {
    hebrew: data.hebrew,
    pronunciation: data.pronunciation,
    size: "hero"
  })), /*#__PURE__*/React.createElement(VerseBlock, {
    verse: data.verse,
    reference: data.verse_reference,
    context: data.context
  }), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement(SectionLabel, null, data.word_heading), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--text-role-body)",
      fontSize: "var(--type-body-sm)",
      margin: 0,
      textWrap: "pretty"
    }
  }, data.word_note)), showRule && /*#__PURE__*/React.createElement(Divider, {
    variant: "diamond",
    style: {
      margin: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "var(--space-6)"
    }
  }, data.readings.map((r, i) => /*#__PURE__*/React.createElement(ReadingNote, {
    key: i,
    heading: r.heading,
    reference: r.reference,
    referenceUrl: r.url
  }, r.text))), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement(SectionLabel, null, "Read and discuss"), /*#__PURE__*/React.createElement(QuestionList, {
    questions: data.questions
  })), /*#__PURE__*/React.createElement(ClosingThought, null, data.closing), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement(SectionLabel, null, "Further reading"), /*#__PURE__*/React.createElement(FurtherReading, data.further_reading)), /*#__PURE__*/React.createElement("footer", {
    style: {
      marginTop: "auto",
      paddingTop: "var(--space-4)",
      borderTop: "var(--border-hairline) solid var(--rule-hairline)",
      display: "grid",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement(SourceList, {
    sources: data.sources,
    footnote: data.footnote
  }), /*#__PURE__*/React.createElement(StatusStamp, null, data.status)));
}
Object.assign(window, {
  StudyPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/rabbis-notes/StudyPage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/rabbis-notes/notes-data.js
try { (() => {
/* Verbatim from uploads/sample-return.json. Copy and hyperlinks are preserved exactly. */
window.NOTES_RETURN = {
  series: "THE RABBI’S NOTES",
  title: "Returning and Making Amends",
  hebrew: "תְּשוּבָה",
  pronunciation: "teshuvah · teh-shoo-VAH · return",
  verse: "“Return, Israel, to the LORD your God.”",
  verse_reference: "Hosea 14:1, NIV (14:2 in Hebrew editions)",
  context: "Hosea addresses Israel after describing its unfaithfulness. The call to return names a relationship: “your God.” Read it first as an appeal to a people. Then consider what returning might ask of a person.",
  word_heading: "What the Hebrew adds",
  word_note: "The verse begins with shuvah, “return,” a form of the verb shuv. Teshuvah is a related noun used in Jewish teaching for repentance. The language invites us to ask where we are turning and what we will do next. “Coming home” is an interpretation of that movement, not a separate dictionary definition.",
  readings: [{
    heading: "A person can begin again",
    text: "In the Talmud, Rabbi Abbahu gives those who return a standing even the consistently righteous do not have. Rabbi Yohanan takes a different view. The disagreement matters: Jewish tradition preserves a conversation about the value of returning, not one simple ranking of people.",
    reference: "Berakhot 34b:22–23",
    url: "https://www.sefaria.org/Berakhot.34b.22?lang=bi&with=Translations"
  }, {
    heading: "The harm still matters",
    text: "Maimonides, the medieval Jewish teacher and legal scholar, says that wronging another person calls for restoring what is owed and seeking that person’s forgiveness. Returning to God does not replace the work of repairing harm to a neighbor.",
    reference: "Mishneh Torah, Repentance 2:9",
    url: "https://mediafiles.theyeshiva.net/theyeshivacnd-d/content/customitems/default/7707/22_teshuva__2_.caa6.pdf?download=true#page=6"
  }],
  questions: ["Read Hosea’s “return” and “your God” together. What does each add to the invitation?", "How do Rabbi Abbahu’s hope and Maimonides’ demand for repair challenge or enrich your understanding of repentance?"],
  closing: "There is room to begin again, and there is work to do. Both belong in the same conversation.",
  further_reading: {
    author: "Rabbi Jonathan Sacks",
    title: "Transforming the Story",
    url: "https://rabbisacks.org/covenant-conversation/vayechi/transforming-the-story/",
    note: "On how teshuvah can change the meaning of our past through the choices we make next."
  },
  sources: [{
    label: "Hosea 14:1 (NIV)",
    url: "https://www.biblegateway.com/passage/?search=Hosea+14%3A1&version=NIV"
  }, {
    label: "Berakhot 34b:22–23",
    url: "https://www.sefaria.org/Berakhot.34b.22?lang=bi&with=Translations"
  }, {
    label: "Maimonides, Repentance 2:9",
    url: "https://mediafiles.theyeshiva.net/theyeshivacnd-d/content/customitems/default/7707/22_teshuva__2_.caa6.pdf?download=true#page=6"
  }],
  footnote: "Rabbinic readings are paraphrased. Bible quotation: NIV. Links open the source texts.",
  status: "PROTOTYPE · DRAFT FOR RABBI EVAN’S REVIEW · SEPTEMBER 14, 2026"
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/rabbis-notes/notes-data.js", error: String((e && e.message) || e) }); }

__ds_ns.Divider = __ds_scope.Divider;

__ds_ns.StatusStamp = __ds_scope.StatusStamp;

__ds_ns.Wordmark = __ds_scope.Wordmark;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.EmailSignup = __ds_scope.EmailSignup;

__ds_ns.ClosingThought = __ds_scope.ClosingThought;

__ds_ns.FurtherReading = __ds_scope.FurtherReading;

__ds_ns.HebrewWord = __ds_scope.HebrewWord;

__ds_ns.QuestionList = __ds_scope.QuestionList;

__ds_ns.ReadingNote = __ds_scope.ReadingNote;

__ds_ns.SectionLabel = __ds_scope.SectionLabel;

__ds_ns.SeriesMasthead = __ds_scope.SeriesMasthead;

__ds_ns.SourceList = __ds_scope.SourceList;

__ds_ns.VerseBlock = __ds_scope.VerseBlock;

})();
