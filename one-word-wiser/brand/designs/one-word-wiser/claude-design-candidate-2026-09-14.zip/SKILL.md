---
name: one-word-wiser-design
description: Use this skill to generate well-branded interfaces and assets for One Word Wiser (Rabbi Evan Moffic), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for protoyping.
user-invocable: true
---

Read the readme.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Three constraints in this brand are not stylistic and must not be traded away:
- Hebrew is native text in Frank Ruhl Libre with all vowel marks preserved and selectable. Never an image, never stripped of nikkud.
- The logo files are provisional stand-ins. Label them provisional in review material, and never redraw the aleph.
- The Rabbi's Notes is a prototype, not a live paid benefit. Do not publish, do not change paid benefits, do not rewrite teaching, and preserve supplied copy and hyperlinks exactly.
