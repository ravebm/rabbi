# One Word Wiser — design system

A short daily letter about Hebrew, the Bible, and Jewish wisdom, from Rabbi Evan Moffic, for Christians, Jewish readers, and anyone curious. This system supports two surfaces: **the daily letter** and **The Rabbi's Notes**, a one-page study companion currently in prototype.

The publication's promise, verbatim and approved:

> The Bible wasn't written in English. One Hebrew word a day, and the verses it opens — Genesis to the Gospels. From Rabbi Evan Moffic. No Hebrew required.

Tagline: *One Hebrew word, one rabbinic teaching, and one wiser way to live.* Short form for headers and bios: **Hebrew for Christians (and curious Jews), from a rabbi.**

## Sources this system was built from

Everything here derives from files supplied in `uploads/`. No repository, Figma file, or live site was provided, and nothing was reconstructed from memory.

| Source | What it gave |
| --- | --- |
| `uploads/01-positioning.md` | Name, tagline, approved description, positioning statement, the voice rules, and the logo direction. The single authority for tone. |
| `uploads/rabbis-notes-return-prototype.pdf` | The study-page prototype: section order, labels, footnotes, status line. |
| `uploads/sample-return.json` | The same page as structured data. Used verbatim in the UI kits. |
| `uploads/EBGaramond[wght].ttf`, `EBGaramond-Italic[wght].ttf`, `FrankRuhlLibre[wght].ttf` | The real webfonts. Copied into `assets/fonts/`, no substitutions needed. |
| `uploads/logo-square-standin.png`, `uploads/wordmark-standin.png` | **Provisional** marks. See *Logo status* below. |

Not supplied, and therefore absent: the final logo files, any design for the letter's own layout, any component library, and the About-page copy (`samples/about-page.md`, referenced by the positioning doc but not included).

### Logo status — read before using a mark

The original final logos are unavailable. `assets/logo-square-provisional.png` and `assets/wordmark-provisional.png` are the supplied stand-ins and **must be labeled provisional wherever they appear in review material** — `<Wordmark showProvisionalNote />` does this. Do not redraw, retrace, or approximate the aleph. If a mark cannot be used, set the words *One Word Wiser* in EB Garamond semibold navy instead.

The positioning doc also flags a production check: at 64px the aleph's upper-right stroke can read as a floating *yud*; thicken that joint on the icon version only if it does.

---

## Content fundamentals

The voice is a rabbi's pulpit voice adapted for the inbox. Warm, plain, unhurried. The full rules are in `uploads/01-positioning.md`; these are the ones that shape layout and copy here.

**Sentence shape.** Short declaratives. Fragments welcome. *"Soft. Open. It ends with a breath."* Rhythm comes from repeating the word of the day naturally, never to a quota.

**Person.** Direct address — *"Say it with me." "Think about the last time you…"* — and first person singular for the rabbi's own judgment. Never a corporate "we."

**Hebrew.** Shown in script **once, at the top, large**, with vowel marks. After that, transliteration only, italicised and glossed in the same breath: *teshuvah*, return. The bolded word inside a transliterated phrase is the word of the day.

**Names of the books.** *Hebrew Bible* and *New Testament*, every time. Not "Old Testament," not "the Christian Bible," never "your Bible" — the reader and the writer share the book. Say "the English" or "the translation" when the point is wording.

**Translation.** Every verse is quoted from the NIV, both testaments, then one line names the Hebrew underneath ("The word under 'return' is *shuvah*"). No "my translation." Never mix translations inside one piece. When the NIV's wording hides the word, that gap *is* the teaching — say it plainly.

**Sources.** One anchor per reflection: Rashi, the Midrash, the Talmud, Heschel, Sacks, Maimonides. Named, told as a story, linked when useful. Never a pile-up. Rabbinic readings are paraphrased and the page says so. The tradition's claims are stated as the tradition's, with delight, never as fact-claims or proof.

**No us and them.** Describe the practice, not the people: "in Jewish prayer," "in every synagogue," "still said in Hebrew today." A Gospel or New Testament line is labeled *Other mentions*.

**Never salesy.** The paid line is a door, not a wall; every free section is a complete gift. Banned in editorial copy: *unlock, exclusive, don't miss*, and any invented scarcity.

**Casing.** Sentence case for titles, headings, and buttons. Uppercase with wide tracking only for small labels and stamps (`THE RABBI'S NOTES`, `PROTOTYPE · DRAFT FOR REVIEW`). Title case never appears in body copy.

**Emoji.** None. Not in the letter, not in the notes, not in UI. The only non-alphabetic glyphs in the system are the divider's ◆, the asterism ⁂, and the middot · used as a separator.

**Strike on sight** (the AI-smell list): framework, journey, navigate, leverage, unlock, delve, tapestry, "here's the thing," "let's dive in," announced connections ("this brings us to"), stacked adjectives, three-beat escalations.

Good, from the supplied sample: *"There is room to begin again, and there is work to do. Both belong in the same conversation."* Two clauses, one idea, no flourish.

---

## Visual foundations

The whole system is one serif, three colours, and a hairline. It should feel like a well-set page, not a website.

**Colour.** Navy `#1B2A41` is the brand. White is the page. Cream `#F6F3EC` is the only tint — used for verse grounds, stamps, and the review desk, never as a full-page wash on the letter. Slate `#5A6B84`/`#8593A8` carries references, captions, and numerals. Brass `#8A6A3B` is the single accent and appears in exactly two places: the divider glyph and the 2px edge on a verse block. No gradients, ever. At most two background colours on a page.

**Type.** EB Garamond for all English, display through caption; Frank Ruhl Libre for Hebrew, with all nikkud preserved as selectable text and set with `lang="he" dir="rtl"`. Hebrew is always larger than the English beside it (64px hero, 26px inline). Body is 19px/1.62 at a 34em measure; questions and closings drop to a 26em measure. Small labels are 15px uppercase at 0.14em tracking; stamps are 12px at 0.1em. Italic does three jobs and no others: transliteration, subtitles and verses, and the closing thought.

**Spacing.** A print ladder — 4, 8, 12, 18, 26, 38, 54, 76 — not a 4px UI grid. Sections are separated by 38px, paragraphs by 18px, the masthead by 54px. Study pages are 816×1056 (US Letter at 96dpi) with a 44/64px margin.

**Backgrounds.** Flat colour only. No imagery, no full-bleed photography, no repeating patterns, no textures, no paper grain, no illustrations. This is deliberate: the positioning doc asks for native text and a small typographic divider as the default, with no mandatory card sets. If a page feels empty, the answer is more whitespace or better type, not an image.

**Borders and rules.** Two weights. A 1px cream `#DFD8C9` hairline between list items and around inputs; a 2px navy rule under a masthead. Nothing heavier.

**Corners.** 0–3px. `--radius-sm` 2px on stamps and images, 3px at most on a page card. No pills except in the token set, which exists for a control this system does not yet have.

**Cards.** There are essentially none. The closest thing is the verse block: cream ground, 2px brass edge on the left, 2px radius, **no shadow and no border**. The one legitimate shadow in the system is `--shadow-page` — a page floating on the review desk — and it never appears in a printed or emailed artifact.

**Shadows, transparency, blur.** No inner shadows. No blur. No frosted panels. No protection gradients; text always sits on flat colour, so contrast is a matter of ink choice rather than scrims. Alpha is used only inside `--shadow-page`, never on type — full-opacity ink on every ground.

**Animation.** Fades and colour transitions at 120–180ms on `cubic-bezier(.4,0,.2,1)`. Nothing moves, scales, bounces, slides, or reveals on scroll. There is no entrance animation anywhere.

**Hover.** Links change ink from navy to brass and the underline follows. Buttons fade to 78% opacity — they do not darken, lighten, lift, or grow. **Press.** No transform; the fade holds. **Focus.** A 2px brass outline at 2px offset. **Disabled.** 38% opacity, cursor default.

**Layout.** One column, centred, measure-bound. Nothing is fixed or sticky; nothing floats. Two columns appear in exactly one place: the pair of rabbinic observations on the study page, which stack on narrow widths. Tables are avoided in editorial material.

**Imagery.** There is none. If photography is ever introduced, the positioning gives the register to match: warm, quiet, unsaturated — but it is not part of this system today, and no placeholder stands in for it.

---

## Iconography

**There is no icon set, and the system does not want one.** Nothing in the supplied material uses icons: no icon font, no SVG sprite, no PNG glyphs, no CDN library. Rather than substitute Lucide or Heroicons and pretend, the system uses words and three typographic marks:

- `◆` U+25C6 — the divider glyph, at 7px in brass. The house ornament.
- `⁂` U+2042 — asterism, an alternative divider for a longer piece.
- `·` U+00B7 — middot, the separator inside pronunciation lines, source runs, and stamps. It does the work an icon would elsewhere.

The only other graphic is the aleph mark itself (provisional PNG). No emoji, in any surface. If a future surface genuinely needs UI icons — a mail app, a dashboard — bring the question back rather than inventing a set here; the closest match in spirit would be a thin-stroke serif-era set, not a rounded UI library.

---

## Intentional additions

Two things exist here that no source defined. Both were needed to make a surface work, and both are flagged so nobody mistakes them for established brand:

- **`EmailSignup`** — the letter's web page and footer need subscribe capture, and none was supplied. Copy is restricted to the approved description; no subscriber counts, no urgency.
- **`Button`** — no button appears in the prototype PDF. The three variants are the minimum needed for "subscribe," "read online," and "download the notes." Deliberately plain.

---

## Index

**Root**

| File | What it is |
| --- | --- |
| `styles.css` | The single entry point consumers link. `@import` lines only. |
| `tokens/colors.css` | Base palette and semantic ink / surface / rule / link tokens. |
| `tokens/typography.css` | Families, scale, weights, leading, tracking, measures, composite text roles. |
| `tokens/spacing.css` | Space ladder, semantic gaps, radii, borders, the one shadow. |
| `tokens/fonts.css` | `@font-face` for EB Garamond (roman + italic) and Frank Ruhl Libre. |
| `tokens/lines.css` | Motion, opacity, and the default `a` / `a:hover` / `::selection` rules. |
| `thumbnail.html` | Homepage tile. |
| `SKILL.md` | Agent-skill wrapper for use outside this project. |

**Assets** — `assets/fonts/` (three variable TTFs), `assets/logo-square-provisional.png`, `assets/wordmark-provisional.png`.

**Components**

| Directory | Components |
| --- | --- |
| `components/brand/` | `Wordmark`, `Divider`, `StatusStamp` |
| `components/core/` | `Button`, `EmailSignup` |
| `components/study/` | `SeriesMasthead`, `SectionLabel`, `HebrewWord`, `VerseBlock`, `ReadingNote`, `QuestionList`, `ClosingThought`, `FurtherReading`, `SourceList` |

Each has a sibling `.d.ts` (props contract) and `.prompt.md` (what, when, example).

**UI kits**

| Kit | Entry |
| --- | --- |
| The Rabbi's Notes — one-page study companion | `ui_kits/rabbis-notes/index.html` ([readme](ui_kits/rabbis-notes/README.md)) |
| Daily letter and welcome page | `ui_kits/daily-letter/index.html` ([readme](ui_kits/daily-letter/README.md)) |

**Templates**

| Template | Entry |
| --- | --- |
| The Rabbi's Notes | `templates/rabbis-notes/RabbisNotes.dc.html` |
| Daily letter | `templates/daily-letter/DailyLetter.dc.html` |

Templates are editable starting files: static markup with the token values written inline, plus a few toggles (divider, further reading, status stamp, subscribe footer). Copy stays verbatim.

**Specimen cards** — `guidelines/*.card.html`, grouped as Colors, Type, Spacing, Brand.

No slide template was supplied, so there are no sample slides.

---

## Standing constraints

These come from the brief and outrank any design preference:

1. Keep designs private. Produce editable review candidates, not published pages.
2. Do not publish anything, do not change paid benefits, and do not rewrite teaching.
3. The Rabbi's Notes is a **prototype**, not a live benefit. Every surface that mentions it says so.
4. Preserve exact copy and hyperlinks. Verify links before a page ships and record the date.
5. Current repository instructions override legacy designs.
