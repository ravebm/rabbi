const { Wordmark, StatusStamp } = window.OneWordWiser_473976;

function LetterHeader({ assetBase = "../..", dateline }) {
  return (
    <header style={{ display: "grid", justifyItems: "center", gap: "var(--space-3)", paddingBottom: "var(--space-5)", borderBottom: "var(--border-hairline) solid var(--rule-hairline)" }}>
      <Wordmark variant="wordmark" height={96} assetBase={assetBase} />
      <div style={{ font: "var(--text-role-caption)", fontSize: "var(--type-micro)", textTransform: "uppercase", letterSpacing: "var(--tracking-status)", color: "var(--text-muted)" }}>{dateline}</div>
      <StatusStamp>Layout specimen · provisional wordmark</StatusStamp>
    </header>
  );
}
Object.assign(window, { LetterHeader });
