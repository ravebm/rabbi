const { EmailSignup, Wordmark, Divider } = window.OneWordWiser_473976;

function LetterFooter({ assetBase = "../.." }) {
  return (
    <footer style={{ display: "grid", gap: "var(--space-4)", justifyItems: "center", textAlign: "center", paddingTop: "var(--space-5)" }}>
      <Divider variant="rule" style={{ margin: 0, width: "100%" }} />
      <Wordmark variant="square" height={40} assetBase={assetBase} />
      <p style={{ font: "var(--text-role-body)", fontSize: "var(--type-body-sm)", color: "var(--text-muted)", maxWidth: "var(--measure-narrow)", margin: 0, textWrap: "pretty" }}>
        The Bible wasn’t written in English. One Hebrew word a day, and the verses it opens — Genesis to the Gospels. From Rabbi Evan Moffic. No Hebrew required.
      </p>
      <EmailSignup label={null} note="No Hebrew required." style={{ margin: "0 auto" }} />
    </footer>
  );
}
Object.assign(window, { LetterFooter });
