# UI kit · Daily letter

**No source layout was supplied for the letter.** The publication's own emails live on Substack, and this kit deliberately does not recreate that product's interface. What is here is the letter *body* — the part the publication controls — composed from this system's foundations and the approved copy.

## What is verbatim, and what is placeholder
- **Verbatim:** the approved description, the tagline, the short social bio, and every sentence of body copy (drawn from `uploads/sample-return.json` so that no teaching is invented here).
- **Composed for this system:** the arrangement — centred masthead, the Hebrew shown once and large, one diamond divider, prose at a 34em measure, sources at the foot.

## Files
| File | What it is |
| --- | --- |
| `index.html` | Letter / Welcome page tabs. |
| `LetterHeader.jsx` | Wordmark, dateline, review stamp. |
| `LetterBody.jsx` | Title, Hebrew hero, verse, prose, closing, sources. |
| `LetterFooter.jsx` | Sign-off mark, approved description, subscribe form. |
| `WelcomePage.jsx` | Publication page: tagline, description, subscribe, note on The Rabbi's Notes. |

Everything on the Welcome page describing The Rabbi's Notes is stamped *in prototype · not a live benefit*. Do not present it as a paid benefit until Rabbi Evan says so.
