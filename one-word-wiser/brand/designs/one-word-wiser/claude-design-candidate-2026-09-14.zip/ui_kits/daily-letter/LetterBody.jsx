/* Layout specimen. The body sentences are taken verbatim from the supplied sample
   return so that no teaching is invented here. */
const { HebrewWord, Divider, SectionLabel, SourceList, ClosingThought } = window.OneWordWiser_473976;

function LetterBody({ data }) {
  const p = { font: "var(--text-role-body)", color: "var(--text-body)", margin: 0, textWrap: "pretty" };
  return (
    <article style={{ display: "grid", gap: "var(--space-5)", maxWidth: "var(--measure-prose)", margin: "0 auto" }}>
      <div style={{ display: "grid", gap: "var(--space-3)", justifyItems: "center", textAlign: "center" }}>
        <h1 style={{ font: "var(--text-role-display)", color: "var(--text-display)", margin: 0, textWrap: "pretty" }}>{data.title}</h1>
        <HebrewWord hebrew={data.hebrew} pronunciation={data.pronunciation} size="hero" />
      </div>

      <blockquote style={{ margin: 0, font: "var(--text-role-subtitle)", color: "var(--text-display)", textAlign: "center" }}>
        {data.verse}
        <footer style={{ font: "var(--text-role-caption)", color: "var(--text-muted)", fontStyle: "normal", marginTop: "var(--space-2)" }}>{data.verse_reference}</footer>
      </blockquote>

      <Divider variant="diamond" style={{ margin: 0 }} />

      <p style={p}>{data.context}</p>
      <p style={p}>{data.word_note}</p>

      <ClosingThought>{data.closing}</ClosingThought>

      <div style={{ borderTop: "var(--border-hairline) solid var(--rule-hairline)", paddingTop: "var(--space-4)", display: "grid", gap: "var(--space-3)" }}>
        <SectionLabel as="h2">Other mentions</SectionLabel>
        <SourceList label="Sources" sources={data.sources} footnote={data.footnote} />
      </div>
    </article>
  );
}
Object.assign(window, { LetterBody });
