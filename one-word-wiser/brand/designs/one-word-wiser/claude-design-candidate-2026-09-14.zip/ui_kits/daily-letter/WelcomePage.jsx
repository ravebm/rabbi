/* The publication's own page: approved description, tagline, and short social bio, verbatim. */
const { Wordmark, EmailSignup, Divider, SectionLabel, Button, StatusStamp } = window.OneWordWiser_473976;

function WelcomePage({ assetBase = "../.." }) {
  const p = { font: "var(--text-role-body)", color: "var(--text-body)", margin: 0, textWrap: "pretty" };
  return (
    <div style={{ display: "grid", gap: "var(--space-6)", maxWidth: "var(--measure-prose)", margin: "0 auto", justifyItems: "center", textAlign: "center" }}>
      <Wordmark variant="wordmark" height={110} assetBase={assetBase} showProvisionalNote />
      <p style={{ ...p, font: "var(--text-role-subtitle)" }}>One Hebrew word, one rabbinic teaching, and one wiser way to live.</p>
      <Divider variant="diamond" style={{ margin: 0 }} />
      <p style={p}>The Bible wasn’t written in English. One Hebrew word a day, and the verses it opens — Genesis to the Gospels. From Rabbi Evan Moffic. No Hebrew required.</p>
      <EmailSignup label={null} note="Hebrew for Christians (and curious Jews), from a rabbi." style={{ margin: "0 auto" }} />
      <div style={{ display: "grid", gap: "var(--space-3)", justifyItems: "center", borderTop: "var(--border-hairline) solid var(--rule-hairline)", paddingTop: "var(--space-5)", width: "100%" }}>
        <SectionLabel as="h2">The Rabbi’s Notes</SectionLabel>
        <p style={{ ...p, fontSize: "var(--type-body-sm)", color: "var(--text-muted)" }}>A one-page study companion: one passage, the Hebrew under it, two rabbinic readings, and two questions to discuss.</p>
        <Button variant="secondary" size="sm" href="../rabbis-notes/index.html">See the sample page</Button>
        <StatusStamp>In prototype · not a live benefit</StatusStamp>
      </div>
    </div>
  );
}
Object.assign(window, { WelcomePage });
