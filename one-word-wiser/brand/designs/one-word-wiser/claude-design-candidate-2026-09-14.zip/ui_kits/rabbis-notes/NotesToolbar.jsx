/* Review chrome around the page. Not part of the printed artifact. */
const { Button, StatusStamp } = window.OneWordWiser_473976;

function NotesToolbar({ view, onView, onPrint }) {
  const tab = active => ({
    font: "var(--text-role-caption)", textTransform: "uppercase", letterSpacing: "var(--tracking-status)",
    padding: "var(--space-2) var(--space-3)", cursor: "pointer", background: "none",
    border: 0, borderBottom: "2px solid " + (active ? "var(--rule-strong)" : "transparent"),
    color: active ? "var(--text-body)" : "var(--text-faint)"
  });
  return (
    <div style={{ width: 816, display: "flex", alignItems: "center", justifyContent: "space-between", gap: "var(--space-4)", margin: "0 auto var(--space-4)" }}>
      <div style={{ display: "flex", gap: "var(--space-2)" }}>
        <button style={tab(view === "page")} onClick={() => onView("page")}>Page</button>
        <button style={tab(view === "sources")} onClick={() => onView("sources")}>Sources</button>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: "var(--space-3)" }}>
        <StatusStamp>Private review copy</StatusStamp>
        <Button variant="secondary" size="sm" onClick={onPrint}>Print / save as PDF</Button>
      </div>
    </div>
  );
}
Object.assign(window, { NotesToolbar });
