/* Verbatim from uploads/sample-return.json. Copy and hyperlinks are preserved exactly. */
window.NOTES_RETURN = {
  series: "THE RABBI’S NOTES",
  title: "Returning and Making Amends",
  hebrew: "תְּשוּבָה",
  pronunciation: "teshuvah · teh-shoo-VAH · return",
  verse: "“Return, Israel, to the LORD your God.”",
  verse_reference: "Hosea 14:1, NIV (14:2 in Hebrew editions)",
  context: "Hosea addresses Israel after describing its unfaithfulness. The call to return names a relationship: “your God.” Read it first as an appeal to a people. Then consider what returning might ask of a person.",
  word_heading: "What the Hebrew adds",
  word_note: "The verse begins with shuvah, “return,” a form of the verb shuv. Teshuvah is a related noun used in Jewish teaching for repentance. The language invites us to ask where we are turning and what we will do next. “Coming home” is an interpretation of that movement, not a separate dictionary definition.",
  readings: [
    { heading: "A person can begin again", text: "In the Talmud, Rabbi Abbahu gives those who return a standing even the consistently righteous do not have. Rabbi Yohanan takes a different view. The disagreement matters: Jewish tradition preserves a conversation about the value of returning, not one simple ranking of people.", reference: "Berakhot 34b:22–23", url: "https://www.sefaria.org/Berakhot.34b.22?lang=bi&with=Translations" },
    { heading: "The harm still matters", text: "Maimonides, the medieval Jewish teacher and legal scholar, says that wronging another person calls for restoring what is owed and seeking that person’s forgiveness. Returning to God does not replace the work of repairing harm to a neighbor.", reference: "Mishneh Torah, Repentance 2:9", url: "https://mediafiles.theyeshiva.net/theyeshivacnd-d/content/customitems/default/7707/22_teshuva__2_.caa6.pdf?download=true#page=6" }
  ],
  questions: [
    "Read Hosea’s “return” and “your God” together. What does each add to the invitation?",
    "How do Rabbi Abbahu’s hope and Maimonides’ demand for repair challenge or enrich your understanding of repentance?"
  ],
  closing: "There is room to begin again, and there is work to do. Both belong in the same conversation.",
  further_reading: { author: "Rabbi Jonathan Sacks", title: "Transforming the Story", url: "https://rabbisacks.org/covenant-conversation/vayechi/transforming-the-story/", note: "On how teshuvah can change the meaning of our past through the choices we make next." },
  sources: [
    { label: "Hosea 14:1 (NIV)", url: "https://www.biblegateway.com/passage/?search=Hosea+14%3A1&version=NIV" },
    { label: "Berakhot 34b:22–23", url: "https://www.sefaria.org/Berakhot.34b.22?lang=bi&with=Translations" },
    { label: "Maimonides, Repentance 2:9", url: "https://mediafiles.theyeshiva.net/theyeshivacnd-d/content/customitems/default/7707/22_teshuva__2_.caa6.pdf?download=true#page=6" }
  ],
  footnote: "Rabbinic readings are paraphrased. Bible quotation: NIV. Links open the source texts.",
  status: "PROTOTYPE · DRAFT FOR RABBI EVAN’S REVIEW · SEPTEMBER 14, 2026"
};
