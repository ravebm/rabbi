# UI kit · The Rabbi's Notes

A recreation of `uploads/rabbis-notes-return-prototype.pdf`, rebuilt from `uploads/sample-return.json` so every string and hyperlink is the supplied copy, unedited.

## Files
| File | What it is |
| --- | --- |
| `index.html` | Interactive review view: Page / Sources tabs, print-to-PDF, "private review copy" stamp. |
| `StudyPage.jsx` | The printed page, 816×1056 (US Letter at 96dpi), composed entirely from this system's `study/` components. |
| `SourcesPanel.jsx` | The separate source-reference view, with full URLs so links can be checked before publication. |
| `NotesToolbar.jsx` | Review chrome. Not part of the printed artifact. |
| `notes-data.js` | The sample return, verbatim. |

## Page order (fixed)
One passage → Hebrew teaching → two brief rabbinic observations → two discussion questions → closing thought → one further-reading link with author, title, and one sentence of relevance → **separately**, the source references.

## Rules this kit enforces
- Copy and hyperlinks are preserved exactly; nothing is rewritten or re-titled.
- Hebrew is native text in Frank Ruhl Libre with all vowel marks intact and selectable. Never an image.
- The provisional aleph mark appears at 26px in the masthead and is labeled provisional in review material.
- The status stamp stays on the page. This is a prototype, not a live paid benefit.
