/* The Rabbi's Notes — one-page study companion. Recreation of the supplied prototype. */
const { SeriesMasthead, SectionLabel, HebrewWord, VerseBlock, ReadingNote, QuestionList, ClosingThought, FurtherReading, SourceList, StatusStamp, Divider } = window.OneWordWiser_473976;

function StudyPage({ data, assetBase = "../..", showRule = true }) {
  return (
    <article style={{
      width: 816, minHeight: 1056, boxSizing: "border-box", background: "var(--surface-card)",
      padding: "44px 64px 34px", display: "flex", flexDirection: "column", gap: "var(--space-5)",
      fontFamily: "var(--font-serif)", color: "var(--text-body)"
    }}>
      <SeriesMasthead series="The Rabbi’s Notes" publication="One Word Wiser" assetBase={assetBase} />

      <div style={{ textAlign: "center", display: "grid", gap: "var(--space-4)" }}>
        <h1 style={{ font: "var(--text-role-title)", color: "var(--text-display)", margin: 0, textWrap: "pretty" }}>{data.title}</h1>
        <HebrewWord hebrew={data.hebrew} pronunciation={data.pronunciation} size="hero" />
      </div>

      <VerseBlock verse={data.verse} reference={data.verse_reference} context={data.context} />

      <section>
        <SectionLabel>{data.word_heading}</SectionLabel>
        <p style={{ font: "var(--text-role-body)", fontSize: "var(--type-body-sm)", margin: 0, textWrap: "pretty" }}>{data.word_note}</p>
      </section>

      {showRule && <Divider variant="diamond" style={{ margin: 0 }} />}

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "var(--space-6)" }}>
        {data.readings.map((r, i) => (
          <ReadingNote key={i} heading={r.heading} reference={r.reference} referenceUrl={r.url}>{r.text}</ReadingNote>
        ))}
      </div>

      <section>
        <SectionLabel>Read and discuss</SectionLabel>
        <QuestionList questions={data.questions} />
      </section>

      <ClosingThought>{data.closing}</ClosingThought>

      <section>
        <SectionLabel>Further reading</SectionLabel>
        <FurtherReading {...data.further_reading} />
      </section>

      <footer style={{ marginTop: "auto", paddingTop: "var(--space-4)", borderTop: "var(--border-hairline) solid var(--rule-hairline)", display: "grid", gap: "var(--space-3)" }}>
        <SourceList sources={data.sources} footnote={data.footnote} />
        <StatusStamp>{data.status}</StatusStamp>
      </footer>
    </article>
  );
}
Object.assign(window, { StudyPage });
