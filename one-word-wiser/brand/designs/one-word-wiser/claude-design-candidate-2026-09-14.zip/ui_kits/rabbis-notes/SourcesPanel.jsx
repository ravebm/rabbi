/* The separate source-reference view. Links are shown in full so they can be checked. */
const { SectionLabel, FurtherReading, StatusStamp } = window.OneWordWiser_473976;

function SourcesPanel({ data }) {
  return (
    <section style={{ width: 816, boxSizing: "border-box", background: "var(--surface-card)", padding: "44px 64px", fontFamily: "var(--font-serif)", display: "grid", gap: "var(--space-5)" }}>
      <div>
        <SectionLabel>Source references</SectionLabel>
        <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "grid", gap: "var(--space-3)" }}>
          {data.sources.map((s, i) => (
            <li key={i} style={{ borderBottom: "var(--border-hairline) solid var(--rule-hairline)", paddingBottom: "var(--space-3)" }}>
              <div style={{ font: "var(--text-role-body)", fontSize: "var(--type-body-sm)" }}><a href={s.url}>{s.label}</a></div>
              <div style={{ font: "var(--text-role-caption)", fontSize: "var(--type-micro)", color: "var(--text-faint)", wordBreak: "break-all", marginTop: 4 }}>{s.url}</div>
            </li>
          ))}
        </ul>
      </div>
      <div>
        <SectionLabel>Further reading</SectionLabel>
        <FurtherReading {...data.further_reading} />
        <div style={{ font: "var(--text-role-caption)", fontSize: "var(--type-micro)", color: "var(--text-faint)", marginTop: "var(--space-2)" }}>Link verified 2026-09-14.</div>
      </div>
      <StatusStamp>{data.footnote}</StatusStamp>
    </section>
  );
}
Object.assign(window, { SourcesPanel });
