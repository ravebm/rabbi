import React from "react";

export function Button({ children, variant = "primary", size = "md", href, disabled, style, ...rest }) {
  const pad = size === "sm" ? "var(--space-2) var(--space-4)" : "var(--space-3) var(--space-5)";
  const tones = {
    primary: { background: "var(--surface-inverse)", color: "var(--text-on-navy)", border: "var(--border-hairline) solid var(--navy-800)" },
    secondary: { background: "transparent", color: "var(--navy-800)", border: "var(--border-hairline) solid var(--navy-800)" },
    quiet: { background: "transparent", color: "var(--text-muted)", border: "var(--border-hairline) solid transparent" }
  };
  const base = {
    font: "var(--text-role-body)", fontSize: size === "sm" ? "var(--type-body-sm)" : "var(--type-body)",
    lineHeight: 1.1, padding: pad, borderRadius: "var(--radius-sm)", cursor: disabled ? "default" : "pointer",
    textDecoration: "none", display: "inline-block", opacity: disabled ? "var(--opacity-disabled)" : 1,
    transition: "opacity var(--duration-base) var(--ease-standard)", ...tones[variant], ...style
  };
  const onEnter = e => { if (!disabled) e.currentTarget.style.opacity = "var(--opacity-hover)"; };
  const onLeave = e => { if (!disabled) e.currentTarget.style.opacity = "1"; };
  if (href) return <a href={href} style={base} onMouseEnter={onEnter} onMouseLeave={onLeave} {...rest}>{children}</a>;
  return <button type="button" disabled={disabled} style={base} onMouseEnter={onEnter} onMouseLeave={onLeave} {...rest}>{children}</button>;
}
