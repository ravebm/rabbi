/** A plain serif button. Subscribe, read online, download the notes — nothing more emphatic exists. */
export interface ButtonProps {
  children?: React.ReactNode;
  /** "primary" navy fill · "secondary" navy hairline outline · "quiet" text only. */
  variant?: "primary" | "secondary" | "quiet";
  size?: "sm" | "md";
  /** Renders an <a> instead of a <button>. */
  href?: string;
  disabled?: boolean;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export declare function Button(props: ButtonProps): JSX.Element;
