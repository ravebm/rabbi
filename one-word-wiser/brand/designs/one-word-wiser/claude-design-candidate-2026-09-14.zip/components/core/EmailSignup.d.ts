/**
 * Email capture for the daily letter. Intentional addition — no source component was supplied.
 */
export interface EmailSignupProps {
  /** One line above the field. Default is the approved hook sentence. */
  label?: React.ReactNode;
  /** Small reassurance line under the field, e.g. "No Hebrew required." */
  note?: React.ReactNode;
  buttonLabel?: string;
  onSubmit?: (e: React.FormEvent) => void;
  style?: React.CSSProperties;
}
export declare function EmailSignup(props: EmailSignupProps): JSX.Element;
