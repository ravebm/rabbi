Subscribe form for the letter's web page and footer.

```jsx
<EmailSignup note="One short letter each morning. No Hebrew required." />
```

Copy comes from the approved description only. Do not add "join thousands" or any count you cannot verify.
