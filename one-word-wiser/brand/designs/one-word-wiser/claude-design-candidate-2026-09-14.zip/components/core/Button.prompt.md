Actions in the letter and on the study page. Serif, near-square corners, no shadow, hover is a slight fade only.

```jsx
<Button variant="primary" href="#">Subscribe</Button>
<Button variant="secondary" size="sm">Download the notes</Button>
```

Label in sentence case. Never "Unlock", "Don't miss", or any invented scarcity.
