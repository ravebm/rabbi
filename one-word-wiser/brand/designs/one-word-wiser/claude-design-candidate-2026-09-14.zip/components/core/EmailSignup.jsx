import React from "react";
import { Button } from "./Button.jsx";

export function EmailSignup({ label = "The Bible wasn't written in English.", note, buttonLabel = "Subscribe", onSubmit, style, ...rest }) {
  return (
    <form
      onSubmit={e => { e.preventDefault(); onSubmit && onSubmit(e); }}
      style={{ display: "flex", flexDirection: "column", gap: "var(--space-3)", maxWidth: "var(--measure-narrow)", ...style }}
      {...rest}
    >
      {label && <div style={{ font: "var(--text-role-body)", color: "var(--text-body)" }}>{label}</div>}
      <div style={{ display: "flex", gap: "var(--space-2)" }}>
        <input
          type="email" required placeholder="you@example.com" aria-label="Email address"
          style={{
            flex: 1, font: "var(--text-role-body)", color: "var(--text-body)", background: "var(--surface-card)",
            border: "var(--border-hairline) solid var(--rule-hairline)", borderRadius: "var(--radius-sm)",
            padding: "var(--space-3) var(--space-4)", minWidth: 0
          }}
        />
        <Button variant="primary">{buttonLabel}</Button>
      </div>
      {note && <div style={{ font: "var(--text-role-caption)", color: "var(--text-muted)" }}>{note}</div>}
    </form>
  );
}
