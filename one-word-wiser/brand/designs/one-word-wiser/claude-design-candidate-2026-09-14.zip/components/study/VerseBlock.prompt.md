One passage per page. Cream ground, brass hairline on the left edge, italic serif.

```jsx
<VerseBlock
  verse={"“Return, Israel, to the LORD your God.”"}
  reference="Hosea 14:1, NIV (14:2 in Hebrew editions)"
  context="Hosea addresses Israel after describing its unfaithfulness…"
/>
```

Quote the NIV verbatim and never mix translations within one page.
