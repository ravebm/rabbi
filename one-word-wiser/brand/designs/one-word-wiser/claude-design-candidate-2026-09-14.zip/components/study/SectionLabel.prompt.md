Labels a movement of the study page. Letter-spaced uppercase serif, slate, never navy-bold.

```jsx
<SectionLabel>What the Hebrew adds</SectionLabel>
```
