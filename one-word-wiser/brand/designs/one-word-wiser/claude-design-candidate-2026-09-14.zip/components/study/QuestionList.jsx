import React from "react";

export function QuestionList({ questions = [], style, ...rest }) {
  return (
    <ol style={{ margin: 0, padding: 0, listStyle: "none", display: "grid", gap: "var(--space-3)", ...style }} {...rest}>
      {questions.map((q, i) => (
        <li key={i} style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: "var(--space-3)", font: "var(--text-role-body)", fontSize: "var(--type-body-sm)", color: "var(--text-body)", textWrap: "pretty" }}>
          <span style={{ color: "var(--text-faint)", fontVariantNumeric: "lining-nums" }}>{i + 1}.</span>
          <span>{q}</span>
        </li>
      ))}
    </ol>
  );
}
