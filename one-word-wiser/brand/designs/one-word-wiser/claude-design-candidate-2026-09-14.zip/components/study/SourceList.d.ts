/** The source references, kept separate from further reading. One inline run at the foot of the page. */
export interface SourceListProps {
  sources?: { label: React.ReactNode; url: string }[];
  /** Leading word. Default "Sources". */
  label?: string;
  /** Translation and paraphrase notice, e.g. "Rabbinic readings are paraphrased. Bible quotation: NIV." */
  footnote?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function SourceList(props: SourceListProps): JSX.Element;
