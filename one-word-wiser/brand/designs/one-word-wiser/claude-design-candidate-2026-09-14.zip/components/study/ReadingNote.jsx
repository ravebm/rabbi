import React from "react";

export function ReadingNote({ heading, children, reference, referenceUrl, style, ...rest }) {
  return (
    <section style={{ ...style }} {...rest}>
      <h3 style={{ font: "var(--text-role-body)", fontWeight: "var(--weight-semibold)", color: "var(--text-display)", margin: "0 0 var(--space-2)" }}>{heading}</h3>
      <p style={{ font: "var(--text-role-body)", fontSize: "var(--type-body-sm)", color: "var(--text-body)", margin: 0, textWrap: "pretty" }}>{children}</p>
      {reference && (
        <div style={{ font: "var(--text-role-caption)", color: "var(--text-muted)", marginTop: "var(--space-2)" }}>
          {referenceUrl ? <a href={referenceUrl}>{reference}</a> : reference}
        </div>
      )}
    </section>
  );
}
