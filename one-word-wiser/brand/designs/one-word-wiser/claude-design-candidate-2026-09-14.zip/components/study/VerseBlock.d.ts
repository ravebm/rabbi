/** The one passage a study page turns on: NIV quotation, its reference, and a short context paragraph. */
export interface VerseBlockProps {
  /** The verse, quoted exactly from the NIV, curly quotes included. */
  verse: React.ReactNode;
  /** e.g. "Hosea 14:1, NIV (14:2 in Hebrew editions)". */
  reference?: React.ReactNode;
  /** One paragraph placing the verse. Optional. */
  context?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function VerseBlock(props: VerseBlockProps): JSX.Element;
