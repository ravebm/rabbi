import React from "react";

export function SectionLabel({ children, as: Tag = "h2", style, ...rest }) {
  return (
    <Tag style={{
      font: "var(--text-role-caption)", fontSize: "var(--type-section)",
      textTransform: "uppercase", letterSpacing: "var(--tracking-section)",
      fontWeight: "var(--weight-semibold)", color: "var(--text-muted)",
      margin: "0 0 var(--space-3)", ...style
    }} {...rest}>{children}</Tag>
  );
}
