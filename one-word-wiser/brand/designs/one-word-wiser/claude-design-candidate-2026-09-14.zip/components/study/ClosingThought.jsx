import React from "react";

export function ClosingThought({ children, style, ...rest }) {
  return (
    <p style={{
      font: "var(--text-role-subtitle)", fontSize: "var(--type-body)", color: "var(--text-display)",
      textAlign: "center", maxWidth: "var(--measure-narrow)", margin: "0 auto", textWrap: "pretty", ...style
    }} {...rest}>{children}</p>
  );
}
