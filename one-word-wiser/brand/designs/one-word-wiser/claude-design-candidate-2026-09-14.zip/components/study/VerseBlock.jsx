import React from "react";

export function VerseBlock({ verse, reference, context, style, ...rest }) {
  return (
    <figure style={{ margin: 0, ...style }} {...rest}>
      <blockquote style={{
        margin: 0, background: "var(--surface-quote)", padding: "var(--space-5) var(--space-5)",
        borderLeft: "var(--border-rule) solid var(--rule-accent)", borderRadius: "var(--radius-sm)",
        font: "var(--text-role-subtitle)", color: "var(--text-display)", textWrap: "pretty"
      }}>{verse}</blockquote>
      {reference && (
        <figcaption style={{ font: "var(--text-role-caption)", color: "var(--text-muted)", marginTop: "var(--space-2)" }}>{reference}</figcaption>
      )}
      {context && (
        <p style={{ font: "var(--text-role-body)", color: "var(--text-body)", margin: "var(--gap-paragraph) 0 0", textWrap: "pretty" }}>{context}</p>
      )}
    </figure>
  );
}
