import React from "react";

export function SourceList({ sources = [], label = "Sources", footnote, style, ...rest }) {
  return (
    <div style={{ font: "var(--text-role-caption)", color: "var(--text-muted)", textWrap: "pretty", ...style }} {...rest}>
      <span>{label}: </span>
      {sources.map((s, i) => (
        <React.Fragment key={i}>
          {i > 0 && <span style={{ color: "var(--text-faint)" }}> · </span>}
          <a href={s.url}>{s.label}</a>
        </React.Fragment>
      ))}
      {footnote && <div style={{ marginTop: "var(--space-1)", color: "var(--text-faint)" }}>{footnote}</div>}
    </div>
  );
}
