The header of any Rabbi's Notes page or PDF.

```jsx
<SeriesMasthead assetBase="../.." />
```

Series name is set in the curly apostrophe form: The Rabbi's Notes.
