/** The two discussion questions. Numbered, hanging figures, no boxes. */
export interface QuestionListProps {
  /** Two questions. More than two crowds a one-page companion. */
  questions?: React.ReactNode[];
  style?: React.CSSProperties;
}
export declare function QuestionList(props: QuestionListProps): JSX.Element;
