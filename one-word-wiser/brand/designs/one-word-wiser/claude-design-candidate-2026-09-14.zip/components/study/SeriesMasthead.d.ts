/**
 * Top rule of a study page: series name left, publication right, 2px navy rule beneath.
 */
export interface SeriesMastheadProps {
  series?: string;
  publication?: string;
  /** Show the small square aleph mark (provisional asset). */
  showMark?: boolean;
  assetBase?: string;
  style?: React.CSSProperties;
}
export declare function SeriesMasthead(props: SeriesMastheadProps): JSX.Element;
