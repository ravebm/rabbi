import React from "react";
import { Wordmark } from "../brand/Wordmark.jsx";

export function SeriesMasthead({ series = "The Rabbi’s Notes", publication = "One Word Wiser", assetBase = "", showMark = true, style, ...rest }) {
  const kicker = {
    font: "var(--text-role-caption)", fontSize: "var(--type-micro)",
    textTransform: "uppercase", letterSpacing: "var(--tracking-status)", color: "var(--text-muted)"
  };
  return (
    <header style={{
      display: "flex", alignItems: "center", justifyContent: "space-between", gap: "var(--space-4)",
      paddingBottom: "var(--space-3)", borderBottom: "var(--border-rule) solid var(--rule-strong)", ...style
    }} {...rest}>
      <div style={{ display: "flex", alignItems: "center", gap: "var(--space-3)" }}>
        {showMark && <Wordmark variant="square" height={26} assetBase={assetBase} />}
        <span style={{ ...kicker, color: "var(--text-body)", fontWeight: "var(--weight-semibold)" }}>{series}</span>
      </div>
      <span style={kicker}>{publication}</span>
    </header>
  );
}
