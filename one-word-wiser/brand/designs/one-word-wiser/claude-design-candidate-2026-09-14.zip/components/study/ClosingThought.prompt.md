The last line of the teaching, before further reading.

```jsx
<ClosingThought>There is room to begin again, and there is work to do. Both belong in the same conversation.</ClosingThought>
```

One sentence, two at most. No call to action here.
