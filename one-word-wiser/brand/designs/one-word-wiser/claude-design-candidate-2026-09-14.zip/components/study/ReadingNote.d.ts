/** One brief rabbinic observation: a heading, a short paragraph, a named source. Two per study page. */
export interface ReadingNoteProps {
  heading: React.ReactNode;
  children?: React.ReactNode;
  /** Source name as it should read, e.g. "Berakhot 34b:22–23". */
  reference?: React.ReactNode;
  /** Link to the source text (Sefaria, BibleGateway, publisher PDF). */
  referenceUrl?: string;
  style?: React.CSSProperties;
}
export declare function ReadingNote(props: ReadingNoteProps): JSX.Element;
