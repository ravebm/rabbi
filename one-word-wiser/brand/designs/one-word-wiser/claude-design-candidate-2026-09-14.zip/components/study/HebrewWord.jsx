import React from "react";

/* Nikkud must survive as selectable text. Never ship the Hebrew as an image,
   and never strip the vowel marks to "clean up" the string. */
export function HebrewWord({ hebrew, pronunciation, size = "hero", align = "center", style, ...rest }) {
  const hero = size === "hero";
  return (
    <div style={{ textAlign: align, ...style }} {...rest}>
      <div lang="he" dir="rtl" style={{
        fontFamily: "var(--font-hebrew)",
        fontSize: hero ? "var(--type-hebrew-hero)" : "var(--type-hebrew-inline)",
        fontWeight: "var(--weight-medium)", lineHeight: "var(--leading-hebrew)",
        color: "var(--text-hebrew)"
      }}>{hebrew}</div>
      {pronunciation && (
        <div style={{
          font: "var(--text-role-body)", fontSize: "var(--type-body-sm)", fontStyle: "italic",
          color: "var(--text-muted)", marginTop: hero ? "var(--space-2)" : "var(--space-1)"
        }}>{pronunciation}</div>
      )}
    </div>
  );
}
