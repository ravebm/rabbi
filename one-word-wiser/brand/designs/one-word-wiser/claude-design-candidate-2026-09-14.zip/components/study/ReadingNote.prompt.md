The two rabbinic observations in the middle of a study page. Lay them out side by side on a wide page, stacked on narrow.

```jsx
<ReadingNote heading="A person can begin again" reference="Berakhot 34b:22–23" referenceUrl="https://www.sefaria.org/Berakhot.34b.22">
  In the Talmud, Rabbi Abbahu gives those who return a standing…
</ReadingNote>
```

Readings are paraphrased and the page says so. Name the interpreter; never assign one view to "the rabbis" as a whole.
