Closes the page. Never merge these with the further-reading link — they do different jobs.

```jsx
<SourceList
  sources={[{label:"Hosea 14:1 (NIV)",url:"…"},{label:"Berakhot 34b:22–23",url:"…"}]}
  footnote="Rabbinic readings are paraphrased. Bible quotation: NIV. Links open the source texts."
/>
```
