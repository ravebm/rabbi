One link per study page, kept separate from the source references.

```jsx
<FurtherReading author="Rabbi Jonathan Sacks" title="Transforming the Story"
  url="https://rabbisacks.org/covenant-conversation/vayechi/transforming-the-story/"
  note="On how teshuvah can change the meaning of our past through the choices we make next." />
```

Hyperlinks are preserved exactly as supplied and are verified before the page ships.
