Sits under a "Read and discuss" label.

```jsx
<QuestionList questions={[
  "Read Hosea’s “return” and “your God” together. What does each add to the invitation?",
  "How do Rabbi Abbahu’s hope and Maimonides’ demand for repair enrich your understanding of repentance?"
]} />
```

Open questions only — nothing with a single correct answer.
