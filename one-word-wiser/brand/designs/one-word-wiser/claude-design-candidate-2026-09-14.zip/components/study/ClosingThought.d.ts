/** One centred italic sentence that closes the page. */
export interface ClosingThoughtProps {
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function ClosingThought(props: ClosingThoughtProps): JSX.Element;
