import React from "react";

export function FurtherReading({ author, title, url, note, style, ...rest }) {
  return (
    <div style={{ ...style }} {...rest}>
      <div style={{ font: "var(--text-role-body)", fontSize: "var(--type-body-sm)", color: "var(--text-body)" }}>
        {author}: <a href={url}><cite style={{ fontStyle: "italic" }}>{title}</cite></a>
      </div>
      {note && <div style={{ font: "var(--text-role-caption)", color: "var(--text-muted)", marginTop: "var(--space-1)", textWrap: "pretty" }}>{note}</div>}
    </div>
  );
}
