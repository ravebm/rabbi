/** Small-caps section label: "What the Hebrew adds", "Read and discuss", "Further reading". */
export interface SectionLabelProps {
  children?: React.ReactNode;
  /** Heading level for document outline. Default "h2". */
  as?: keyof JSX.IntrinsicElements;
  style?: React.CSSProperties;
}
export declare function SectionLabel(props: SectionLabelProps): JSX.Element;
