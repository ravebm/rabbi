Shows the Hebrew script once, at the top, large. After this, use transliteration only.

```jsx
<HebrewWord hebrew="תְּשוּבָה" pronunciation="teshuvah · teh-shoo-VAH · return" />
```

Set in Frank Ruhl Libre with `lang="he" dir="rtl"`. Vowel marks are always preserved and selectable.
