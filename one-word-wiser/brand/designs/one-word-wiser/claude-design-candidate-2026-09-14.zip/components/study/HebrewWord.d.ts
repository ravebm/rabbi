/**
 * The Hebrew word, shown once and large, with its transliteration/gloss line beneath.
 */
export interface HebrewWordProps {
  /** Pointed Hebrew, vowel marks included, as a real string: "תְּשוּבָה". */
  hebrew: string;
  /** Transliteration, syllable stress, gloss: "teshuvah · teh-shoo-VAH · return". */
  pronunciation?: string;
  /** "hero" 64px (top of page, once) or "inline" 26px (within prose). */
  size?: "hero" | "inline";
  align?: "center" | "left" | "right";
  style?: React.CSSProperties;
}
export declare function HebrewWord(props: HebrewWordProps): JSX.Element;
