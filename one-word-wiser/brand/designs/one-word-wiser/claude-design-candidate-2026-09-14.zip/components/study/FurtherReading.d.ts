/** Exactly one further-reading link: author, title, and one sentence on why it is relevant. */
export interface FurtherReadingProps {
  author: React.ReactNode;
  title: React.ReactNode;
  url: string;
  /** One sentence of relevance. Not a summary of the piece. */
  note?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function FurtherReading(props: FurtherReadingProps): JSX.Element;
