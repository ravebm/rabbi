/** The house typographic divider: a hairline broken by one small glyph. No illustrations. */
export interface DividerProps {
  /** "diamond" (default) · "asterism" (⁂) · "dots" · "rule" (plain hairline, no glyph). */
  variant?: "diamond" | "asterism" | "dots" | "rule";
  /** Glyph colour: brass accent (default) or faint slate. */
  tone?: "accent" | "faint";
  width?: string | number;
  style?: React.CSSProperties;
}
export declare function Divider(props: DividerProps): JSX.Element;
