import React from "react";

/* Provisional marks. The final logos were not supplied; these stand-ins are
   labeled provisional wherever they appear in review material. */
const SQUARE = "/assets/logo-square-provisional.png";
const WORDMARK = "/assets/wordmark-provisional.png";

export function Wordmark({ variant = "wordmark", height, assetBase = "", showProvisionalNote = false, style, ...rest }) {
  const isSquare = variant === "square";
  const src = assetBase + (isSquare ? SQUARE : WORDMARK);
  const h = height || (isSquare ? 48 : 96);
  return (
    <span style={{ display: "inline-flex", flexDirection: "column", alignItems: "center", gap: "var(--space-2)", ...style }} {...rest}>
      <img src={src} alt="One Word Wiser" style={{ height: h, width: "auto", display: "block", borderRadius: isSquare ? "var(--radius-sm)" : 0 }} />
      {showProvisionalNote && (
        <span style={{ font: "var(--text-role-caption)", color: "var(--text-faint)", letterSpacing: "var(--tracking-status)", textTransform: "uppercase", fontSize: "var(--type-micro)" }}>
          Provisional mark
        </span>
      )}
    </span>
  );
}
