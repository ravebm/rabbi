The brand lockup — use `square` at avatar/favicon sizes and `wordmark` for mastheads, covers, and email headers.

```jsx
<Wordmark variant="wordmark" height={88} assetBase="../.." showProvisionalNote />
```

Both files are **provisional stand-ins**; the final logos were never supplied. Pass `showProvisionalNote` on anything that goes out for review. Never redraw the aleph — if the asset is unavailable, set the brand name in EB Garamond instead.
