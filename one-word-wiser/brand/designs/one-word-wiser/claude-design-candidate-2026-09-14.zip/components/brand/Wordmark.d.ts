/**
 * The One Word Wiser lockup. Square aleph avatar or the full wordmark with byline.
 */
export interface WordmarkProps {
  /** "square" = navy aleph avatar/favicon. "wordmark" = full lockup with "with Rabbi Evan Moffic". */
  variant?: "square" | "wordmark";
  /** Rendered image height in px. Defaults: 48 (square), 96 (wordmark). */
  height?: number;
  /** Prefix for the asset path when the page is not served from the project root, e.g. "../..". */
  assetBase?: string;
  /** Print the "Provisional mark" caption underneath. Use in any review material. */
  showProvisionalNote?: boolean;
  style?: React.CSSProperties;
}
export declare function Wordmark(props: WordmarkProps): JSX.Element;
