/** Review/provenance stamp — prototype status, draft dates, "provisional asset" notices. Never marketing copy. */
export interface StatusStampProps {
  children?: React.ReactNode;
  /** "quiet" = slate on cream (default). "inverse" = cream on navy, for a page footer band. */
  tone?: "quiet" | "inverse";
  style?: React.CSSProperties;
}
export declare function StatusStamp(props: StatusStampProps): JSX.Element;
