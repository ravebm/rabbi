import React from "react";

export function StatusStamp({ children, tone = "quiet", style, ...rest }) {
  const inverse = tone === "inverse";
  return (
    <div style={{
      font: "var(--text-role-caption)", fontSize: "var(--type-micro)",
      textTransform: "uppercase", letterSpacing: "var(--tracking-status)",
      color: inverse ? "var(--text-on-navy)" : "var(--status-ink)",
      background: inverse ? "var(--surface-inverse)" : "var(--status-surface)",
      padding: "var(--space-2) var(--space-4)", borderRadius: "var(--radius-sm)",
      display: "inline-block", ...style
    }} {...rest}>{children}</div>
  );
}
