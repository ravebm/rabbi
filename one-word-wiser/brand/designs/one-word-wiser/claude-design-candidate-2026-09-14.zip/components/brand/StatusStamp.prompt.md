Marks a page as unpublished or an asset as provisional.

```jsx
<StatusStamp>Prototype · draft for Rabbi Evan's review · September 14, 2026</StatusStamp>
```

Keep the text factual. Nothing in this system may imply a published or paid benefit that does not exist.
