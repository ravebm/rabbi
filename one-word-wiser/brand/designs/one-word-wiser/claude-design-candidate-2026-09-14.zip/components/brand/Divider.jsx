import React from "react";

/* The only ornament this system allows. Native text, never an image. */
const GLYPHS = { diamond: "\u25C6", asterism: "\u2042", dots: "\u00B7 \u00B7 \u00B7" };

export function Divider({ variant = "diamond", tone = "accent", width = "100%", style, ...rest }) {
  const color = tone === "accent" ? "var(--rule-accent)" : "var(--text-faint)";
  if (variant === "rule") {
    return <hr style={{ border: 0, borderTop: "var(--border-hairline) solid var(--rule-hairline)", width, margin: "var(--gap-block) 0", ...style }} {...rest} />;
  }
  return (
    <div role="separator" aria-hidden="true" style={{ display: "flex", alignItems: "center", gap: "var(--space-4)", width, margin: "var(--gap-block) 0", ...style }} {...rest}>
      <span style={{ flex: 1, height: 1, background: "var(--rule-hairline)" }} />
      <span style={{ color, fontSize: variant === "diamond" ? 7 : 15, lineHeight: 1, letterSpacing: "0.2em", fontFamily: "var(--font-serif)" }}>{GLYPHS[variant]}</span>
      <span style={{ flex: 1, height: 1, background: "var(--rule-hairline)" }} />
    </div>
  );
}
