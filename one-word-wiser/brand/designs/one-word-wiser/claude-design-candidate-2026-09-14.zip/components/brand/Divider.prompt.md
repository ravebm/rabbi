Separates movements of a letter or sections of a study page. It is the system's only decorative element.

```jsx
<Divider variant="diamond" />
<Divider variant="rule" />
```

Use at most two per page. `rule` between list items, `diamond` between major sections.
